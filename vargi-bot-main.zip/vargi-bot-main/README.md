# vargi-bot

***with the help of robotic operating system***

***We make a robotic arm which can work in workshop managing packeges***

***first we learnt the communication between subscriber and publisher using mqtt communication protocol***

***by using of python APIs we append data into google spreadsheet***


https://user-images.githubusercontent.com/70278767/119706686-ec504000-be77-11eb-84ae-d5703b24946c.mp4


***then by Rviz we make an arm package and we created environment in Gazebo, Arm design in xml***

***then using python APIS we made out End effector to move on package position***


https://user-images.githubusercontent.com/70278767/119706777-08ec7800-be78-11eb-83c2-4361be593887.mp4


***then we sorted the packeges in Gazebo environment using Logical Camera***


https://user-images.githubusercontent.com/70278767/119707500-d8590e00-be78-11eb-8f3a-45c6acfb4b7a.mp4




***further development is being continued on Arm*** 
